//
//  ImageCell.h
//  HelloWord
//
//  Created by zhangwenqiang on 16/5/9.
//  Copyright © 2016年 zhangwenqiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageCell : UICollectionViewCell

@property(nonatomic,assign) CGFloat cornerRadius;

@property(nonatomic,strong) NSString* image;

@end
